from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    url='first.com',
    py_modules=['vsearch'])
